<!--- Footer -->

<footer class="footer mt-auto py-3 bg-secondary ">
	<div class="container-fluid padding ">
		<div class="row text-center">
			<div class="col-md-4">
				
				<hr class="bg-dark">
				<p>01792-855-957</p>
				<p>info@solutionbrisk.com</p>
				<p>ISO: I9002</p>
				<p>Dhaka, Bangladesh</p>
			</div>
			<div class="col-md-4">
				<hr class="bg-dark">
				<h5>Our hours</h5>
				<hr class="bg-dark">
				<p>Sunday - Thursday: 9am - 5pm</p>
				<p>Friday : 10am - 4pm</p>
				<p>Saturday : closed</p> 
			</div>
			<div class="col-md-4">
				<hr class="bg-dark"> 
				<h5>Service Area</h5>
				<hr class="bg-dark">
				<p >Uttara, Dhaka, 1230</p>
				<p>Bashundhara, Dhaka, 1229</p>
				<p>Banani, Dhaka, 1213</p>
				<p>Gulshan, Dhaka, 1212</p>
			</div>
			<div class="col-12">
				<hr class="bg-dark">
				<h5>&copy; All Right Reserved by SolutionBrisk</h5>
			</div>
		</div>
	</div>
</footer>